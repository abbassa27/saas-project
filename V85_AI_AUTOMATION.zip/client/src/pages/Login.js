
// 🚀 NEW FEATURE START: LOGIN PAGE
import React, { useState } from "react";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async () => {
        const res = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        localStorage.setItem("token", data.token);
        window.location.href = "/dashboard";
    };

    return (
        <div style={{padding:20}}>
            <h2>Login</h2>
            <input placeholder="email" onChange={e=>setEmail(e.target.value)} />
            <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)} />
            <button onClick={handleLogin}>Login</button>
        </div>
    );
}
// 🚀 NEW FEATURE END: LOGIN PAGE
