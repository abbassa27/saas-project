const express=require("express");
const mongoose=require("mongoose");
require("dotenv").config();

const app=express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI);

const Post=require("mongoose").model("Post",new mongoose.Schema({
 title:String,content:String,date:{type:Date,default:Date.now}
}));

setInterval(async ()=>{
 await Post.create({title:"Auto Post",content:"SEO content"});
},60000);

app.get("/api/blog",async(req,res)=>{
 res.json(await Post.find().sort({date:-1}));
});

app.get("/cta",(req,res)=>res.redirect(process.env.UPWORK_URL));

app.listen(5000);
