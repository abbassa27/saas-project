
// 🚀 NEW FEATURE START: AUTH ROUTES
const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

router.post("/register", async (req, res) => {
    const { email, password } = req.body;
    try {
        let user = await User.findOne({ email });
        if (user) return res.status(400).json({ msg: "User exists" });

        const hashed = await bcrypt.hash(password, 10);
        user = new User({ email, password: hashed });
        await user.save();

        res.json({ msg: "Registered" });
    } catch (err) {
        res.status(500).send("Server error");
    }
});

router.post("/login", async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ msg: "Invalid creds" });

        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(400).json({ msg: "Invalid creds" });

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
        res.json({ token });
    } catch (err) {
        res.status(500).send("Server error");
    }
});

module.exports = router;
// 🚀 NEW FEATURE END: AUTH ROUTES
