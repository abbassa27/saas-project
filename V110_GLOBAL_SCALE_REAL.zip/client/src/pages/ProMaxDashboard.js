
// =====================
// 🚀 NEW FEATURE START: PRO MAX DASHBOARD
// =====================
import React from "react";
import FadeIn from "../pro_ui/FadeIn";
import Chart from "../pro_ui/Chart";

export default function ProMaxDashboard(){
    return(
        <div style={{padding:40}}>
            <FadeIn>
                <h1>📊 Pro Dashboard</h1>
            </FadeIn>

            <FadeIn>
                <Chart/>
            </FadeIn>

            <FadeIn>
                <div style={{
                    marginTop:20,
                    padding:20,
                    borderRadius:20,
                    background:"rgba(255,255,255,0.05)"
                }}>
                    <p>Real analytics preview</p>
                </div>
            </FadeIn>
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
