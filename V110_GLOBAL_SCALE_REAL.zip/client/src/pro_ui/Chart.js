
// =====================
// 🚀 NEW FEATURE START: SIMPLE CHART
// =====================
import React from "react";

export default function Chart(){
    const data = [10,20,15,30,25];

    return(
        <div style={{display:"flex",gap:10}}>
            {data.map((v,i)=>(
                <div key={i} style={{
                    width:20,
                    height:v*3,
                    background:"gold"
                }}/>
            ))}
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
