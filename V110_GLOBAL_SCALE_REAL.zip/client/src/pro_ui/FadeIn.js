
// =====================
// 🚀 NEW FEATURE START: FADE IN ANIMATION
// =====================
import React, { useEffect, useState } from "react";

export default function FadeIn({children}){
    const [show,setShow]=useState(false);

    useEffect(()=>{
        setTimeout(()=>setShow(true),100);
    },[]);

    return(
        <div style={{
            opacity: show ? 1 : 0,
            transform: show ? "translateY(0px)" : "translateY(20px)",
            transition: "all 0.6s ease"
        }}>
            {children}
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
