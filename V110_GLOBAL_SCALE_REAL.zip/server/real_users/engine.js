
// =====================
// 🚀 NEW FEATURE START: REAL USERS ENGINE
// =====================
let users = [];

const createUser = (user) => {
    users.push({ ...user, createdAt: new Date(), plan: "free" });
};

const upgradeUser = (index) => {
    if(users[index]) users[index].plan = "pro";
};

const getUsers = () => users;

module.exports = { createUser, upgradeUser, getUsers };
// =====================
// 🚀 NEW FEATURE END
// =====================
