
// =====================
// 🚀 NEW FEATURE START: GLOBAL SYSTEM ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { scaleSystem } = require("../scaling/globalScaling");
const { createUser, upgradeUser, getUsers } = require("../real_users/engine");
const { launchCampaign, optimizeCampaigns, getCampaigns } = require("../marketing_real/growthEngine");

router.get("/scale", (req,res)=>{
    scaleSystem();
    res.json({status:"scaled"});
});

router.post("/user", (req,res)=>{
    createUser(req.body);
    res.json({status:"user created"});
});

router.post("/upgrade", (req,res)=>{
    upgradeUser(req.body.index);
    res.json({status:"upgraded"});
});

router.get("/users", (req,res)=>{
    res.json({users:getUsers()});
});

router.post("/campaign", (req,res)=>{
    launchCampaign(req.body.type);
    res.json({status:"campaign launched"});
});

router.get("/campaigns", (req,res)=>{
    res.json({data:getCampaigns()});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
