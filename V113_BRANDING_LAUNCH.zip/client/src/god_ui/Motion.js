
// =====================
// 🚀 NEW FEATURE START: MOTION ENGINE (FRAMER-LIKE)
// =====================
import React, { useEffect, useState } from "react";

export default function Motion({children}){
    const [visible,setVisible]=useState(false);

    useEffect(()=>{
        setTimeout(()=>setVisible(true),100);
    },[]);

    return(
        <div style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "scale(1)" : "scale(0.95)",
            transition: "all 0.5s cubic-bezier(0.22, 1, 0.36, 1)"
        }}>
            {children}
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
