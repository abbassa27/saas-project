
// =====================
// 🚀 NEW FEATURE START: LIVE DATA HOOK
// =====================
import { useEffect, useState } from "react";

export default function useLiveData(){
    const [data,setData]=useState(0);

    useEffect(()=>{
        const interval = setInterval(()=>{
            setData(prev=>prev+1);
        },2000);

        return ()=>clearInterval(interval);
    },[]);

    return data;
}
// =====================
// 🚀 NEW FEATURE END
// =====================
