
// =====================
// 🚀 NEW FEATURE START: REAL LINE CHART
// =====================
import React from "react";

export default function RealChart(){
    const data = [5,15,10,20,30,25];

    return(
        <svg width="300" height="100">
            {data.map((v,i)=>(
                <circle key={i} cx={i*50} cy={100-v*3} r="4" fill="gold"/>
            ))}
            <polyline
                fill="none"
                stroke="gold"
                strokeWidth="2"
                points={data.map((v,i)=>`${i*50},${100-v*3}`).join(" ")}
            />
        </svg>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
