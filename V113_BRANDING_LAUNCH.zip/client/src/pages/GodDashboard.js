
// =====================
// 🚀 NEW FEATURE START: GOD MODE DASHBOARD
// =====================
import React from "react";
import Motion from "../god_ui/Motion";
import RealChart from "../god_ui/RealChart";
import useLiveData from "../god_ui/useLiveData";

export default function GodDashboard(){
    const live = useLiveData();

    return(
        <div style={{padding:40}}>
            <Motion>
                <h1>🦄 God Dashboard</h1>
            </Motion>

            <Motion>
                <RealChart/>
            </Motion>

            <Motion>
                <p>Live users: {live}</p>
            </Motion>
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
