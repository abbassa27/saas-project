
// =====================
// 🚀 NEW FEATURE START: BILLING SYSTEM (NO STRIPE)
// =====================
let invoices = [];

const createInvoice = (user, amount) => {
    invoices.push({user, amount, status:"pending", date:new Date()});
};

const markPaid = (index) => {
    if(invoices[index]) invoices[index].status="paid";
};

const getInvoices = () => invoices;

module.exports = { createInvoice, markPaid, getInvoices };
// =====================
// 🚀 NEW FEATURE END
// =====================
