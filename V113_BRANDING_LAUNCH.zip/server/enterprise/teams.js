
// =====================
// 🚀 NEW FEATURE START: TEAMS + ROLES SYSTEM
// =====================
let teams = [];

const createTeam = (name) => {
    teams.push({ name, members: [] });
};

const addMember = (teamIndex, user, role) => {
    if(teams[teamIndex]){
        teams[teamIndex].members.push({user, role});
    }
};

const getTeams = () => teams;

module.exports = { createTeam, addMember, getTeams };
// =====================
// 🚀 NEW FEATURE END
// =====================
