
// =====================
// 🚀 NEW FEATURE START: ENTERPRISE ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { createInvoice, markPaid, getInvoices } = require("../enterprise/billing");
const { createTeam, addMember, getTeams } = require("../enterprise/teams");
const { infraStatus } = require("../enterprise/infra");

// billing
router.post("/invoice",(req,res)=>{
    createInvoice(req.body.user, req.body.amount);
    res.json({status:"invoice created"});
});

router.post("/pay",(req,res)=>{
    markPaid(req.body.index);
    res.json({status:"paid"});
});

router.get("/invoices",(req,res)=>{
    res.json({data:getInvoices()});
});

// teams
router.post("/team",(req,res)=>{
    createTeam(req.body.name);
    res.json({status:"team created"});
});

router.post("/member",(req,res)=>{
    addMember(req.body.teamIndex, req.body.user, req.body.role);
    res.json({status:"member added"});
});

router.get("/teams",(req,res)=>{
    res.json({teams:getTeams()});
});

// infra
router.get("/infra",(req,res)=>{
    res.json(infraStatus());
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
