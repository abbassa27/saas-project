
// 🚀 NEW FEATURE START: ANALYTICS PAGE
import React, { useEffect, useState } from "react";

export default function Analytics() {
    const [logs, setLogs] = useState([]);

    useEffect(() => {
        fetch("/api/analytics")
        .then(res => res.json())
        .then(data => setLogs(data.logs));
    }, []);

    return (
        <div style={{padding:20}}>
            <h2>System Analytics</h2>
            <ul>
                {logs.map((l,i)=>(
                    <li key={i}>{l.event} - {new Date(l.time).toLocaleString()}</li>
                ))}
            </ul>
        </div>
    );
}
// 🚀 NEW FEATURE END: ANALYTICS PAGE
