
// 🚀 NEW FEATURE START: ANALYTICS ROUTES
const express = require("express");
const router = express.Router();
const { getLogs } = require("../analytics/tracker");

router.get("/", (req, res) => {
    res.json({ logs: getLogs() });
});

module.exports = router;
// 🚀 NEW FEATURE END: ANALYTICS ROUTES
