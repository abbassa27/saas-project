
        // 🚀 NEW FEATURE START: PAYMENT SYSTEM
        let payments = [];
        const createPayment = (user, amount) => {
            payments.push({ user, amount, status:"pending", date:new Date() });
        };
        const getPayments = () => payments;
        module.exports = { createPayment, getPayments };
        // 🚀 NEW FEATURE END
        