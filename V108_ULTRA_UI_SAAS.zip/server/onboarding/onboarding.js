
        // 🚀 NEW FEATURE START: ONBOARDING SYSTEM
        const onboardUser = (user) => {
            return { message: `Welcome ${user}`, steps:["setup","first campaign","first client"] };
        };
        module.exports = { onboardUser };
        // 🚀 NEW FEATURE END
        