
// =====================
// 🚀 NEW FEATURE START: JWT AUTH
// =====================
const jwt = require("jsonwebtoken");
const SECRET = process.env.JWT_SECRET || "secret";

const generateToken = (user) => jwt.sign(user, SECRET);
const verifyToken = (token) => jwt.verify(token, SECRET);

module.exports = { generateToken, verifyToken };
// =====================
// 🚀 NEW FEATURE END
// =====================
