
// =====================
// 🚀 NEW FEATURE START: MONGO DB CONNECTOR
// =====================
const connectDB = async () => {
    console.log("MongoDB ready (connect your URI in .env)");
};
module.exports = { connectDB };
// =====================
// 🚀 NEW FEATURE END
// =====================
