
// =====================
// 🚀 NEW FEATURE START: CRM PIPELINE
// =====================
let deals = [];

const addLead = (lead) => {
    deals.push({ ...lead, stage: "new" });
};

const moveStage = (index, stage) => {
    if (deals[index]) deals[index].stage = stage;
};

const autoClose = () => {
    deals = deals.map(d => ({...d, stage:"closed"}));
};

const getDeals = () => deals;

module.exports = { addLead, moveStage, autoClose, getDeals };
// =====================
// 🚀 NEW FEATURE END
// =====================
