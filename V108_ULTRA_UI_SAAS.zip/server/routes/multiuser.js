
// =====================
// 🚀 NEW FEATURE START: MULTI USER ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { register, getUsers, useLimit } = require("../multiuser/system");

router.post("/register", (req,res)=>{
    register(req.body);
    res.json({status:"registered"});
});

router.get("/", (req,res)=>{
    res.json({users:getUsers()});
});

router.post("/limit", (req,res)=>{
    useLimit(req.body.index);
    res.json({status:"limit used"});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
