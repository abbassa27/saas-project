
// =====================
// 🚀 NEW FEATURE START: AI LEARNING ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { learn, improve, getHistory } = require("../ai_learning/learningEngine");

router.post("/learn", (req,res)=>{
    learn(req.body.input, req.body.output, req.body.feedback);
    res.json({status:"learned"});
});

router.get("/improve", (req,res)=>{
    res.json({message: improve()});
});

router.get("/history", (req,res)=>{
    res.json({data:getHistory()});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
