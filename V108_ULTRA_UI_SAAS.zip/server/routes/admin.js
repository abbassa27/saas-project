
// 🚀 NEW FEATURE START: ADMIN ROUTES
const express = require("express");
const router = express.Router();

router.get("/stats", (req, res) => {
    res.json({
        users: 120,
        revenue: 999,
        activeTenants: 5
    });
});

module.exports = router;
// 🚀 NEW FEATURE END: ADMIN ROUTES
