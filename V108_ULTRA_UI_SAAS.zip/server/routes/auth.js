
// =====================
// 🚀 NEW FEATURE START: AUTH ROUTES
// =====================
const express = require("express");
const router = express.Router();
const { generateToken } = require("../auth/jwt");

router.post("/login", (req,res)=>{
    const token = generateToken({user:req.body.user});
    res.json({token});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
