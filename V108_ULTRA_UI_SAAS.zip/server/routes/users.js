
        // 🚀 NEW FEATURE START: USERS ROUTES
        const express = require("express");
        const router = express.Router();
        const { createUser, getUsers } = require("../users/UserProfile");

        router.post("/create", (req,res)=>{
            createUser(req.body);
            res.json({status:"user_created"});
        });

        router.get("/", (req,res)=>{
            res.json({users:getUsers()});
        });

        module.exports = router;
        // 🚀 NEW FEATURE END
        