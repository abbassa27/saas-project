
// =====================
// 🚀 NEW FEATURE START: RANK ROUTES
// =====================
const express = require("express");
const router = express.Router();
const { trackRank } = require("../seo_rank/rankTracker");

router.get("/", (req,res)=>{
    res.json(trackRank("saas"));
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
