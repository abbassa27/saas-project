
// =====================
// 🚀 NEW FEATURE START: CRM ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { addLead, moveStage, autoClose, getDeals } = require("../crm/pipeline");

router.post("/lead", (req,res)=>{
    addLead(req.body);
    res.json({status:"lead added"});
});

router.post("/stage", (req,res)=>{
    moveStage(req.body.index, req.body.stage);
    res.json({status:"updated"});
});

router.get("/", (req,res)=>{
    res.json({deals:getDeals()});
});

router.post("/close", (req,res)=>{
    autoClose();
    res.json({status:"closed"});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
