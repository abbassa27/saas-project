
// =====================
// 🚀 NEW FEATURE START: BLOG ROUTES
// =====================
const express = require("express");
const router = express.Router();
const { createPost, getPosts } = require("../blog/cms");

router.post("/create",(req,res)=>{
    createPost(req.body);
    res.json({status:"created"});
});

router.get("/",(req,res)=>{
    res.json({posts:getPosts()});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
