
// 🚀 NEW FEATURE START: REVENUE ROUTES
const express = require("express");
const router = express.Router();

const { addRevenue, getRevenue } = require("../revenue/revenueTracker");
const { convertClient, getClients } = require("../revenue/conversionSystem");
const { closeDeal } = require("../revenue/aiCloser");

router.post("/add", (req, res) => {
    addRevenue(req.body.amount);
    res.json({ status: "ok" });
});

router.get("/", (req, res) => {
    res.json({ revenue: getRevenue() });
});

router.post("/convert", (req, res) => {
    convertClient(req.body.client);
    res.json({ status: "converted" });
});

router.post("/close", (req, res) => {
    const result = closeDeal(req.body.client);
    res.json({ result });
});

router.get("/clients", (req, res) => {
    res.json({ clients: getClients() });
});

module.exports = router;
// 🚀 NEW FEATURE END: REVENUE ROUTES
