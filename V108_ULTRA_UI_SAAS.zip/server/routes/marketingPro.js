
// =====================
// 🚀 NEW FEATURE START: MARKETING PRO ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { sendEmail, followUp } = require("../marketing_pro/emailSystem");
const { postLinkedIn, postMedium } = require("../marketing_pro/autoPosting");
const { analyzeCompetitors, optimizeContent } = require("../marketing_pro/seoAdvanced");

router.post("/email", (req,res)=>{
    sendEmail(req.body.to, req.body.subject);
    res.json({status:"email sent"});
});

router.post("/followup", (req,res)=>{
    followUp(req.body.client);
    res.json({status:"follow-up sent"});
});

router.post("/post", (req,res)=>{
    postLinkedIn(req.body.content);
    postMedium(req.body.content);
    res.json({status:"posted"});
});

router.get("/seo", (req,res)=>{
    const data = analyzeCompetitors("saas");
    res.json({data});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
