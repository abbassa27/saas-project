
// 🚀 NEW FEATURE START: LEADS ROUTES
const express = require("express");
const router = express.Router();
const { getLeads } = require("../services/leadService");

router.post("/", async (req, res) => {
    const { keyword } = req.body;
    const leads = await getLeads(keyword);
    res.json({ leads });
});

module.exports = router;
// 🚀 NEW FEATURE END: LEADS ROUTES
