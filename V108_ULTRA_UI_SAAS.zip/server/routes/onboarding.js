
        // 🚀 NEW FEATURE START: ONBOARDING ROUTES
        const express = require("express");
        const router = express.Router();
        const { onboardUser } = require("../onboarding/onboarding");

        router.post("/", (req,res)=>{
            res.json(onboardUser(req.body.user));
        });

        module.exports = router;
        // 🚀 NEW FEATURE END
        