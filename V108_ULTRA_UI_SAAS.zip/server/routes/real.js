
// 🚀 NEW FEATURE START: REAL CLIENT ROUTES
const express = require("express");
const router = express.Router();

const { scrapeJobs } = require("../real/upworkScraper");
const { sendProposal } = require("../real/autoApply");
const { trackConversion, getConversions } = require("../real/conversion");

router.post("/scrape", async (req, res) => {
    const jobs = await scrapeJobs(req.body.keyword);
    res.json({ jobs });
});

router.post("/apply", (req, res) => {
    sendProposal(req.body.job);
    trackConversion("proposal_sent");
    res.json({ status: "sent" });
});

router.get("/conversions", (req, res) => {
    res.json({ data: getConversions() });
});

module.exports = router;
// 🚀 NEW FEATURE END: REAL CLIENT ROUTES
