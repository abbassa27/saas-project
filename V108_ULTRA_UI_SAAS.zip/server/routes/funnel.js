
// 🚀 NEW FEATURE START: FUNNEL ROUTES
const express = require("express");
const router = express.Router();
const { generateProposal, generateCTA } = require("../services/funnelService");

router.post("/proposal", (req, res) => {
    const { clientName, project } = req.body;
    res.json({ proposal: generateProposal(clientName, project) });
});

router.get("/cta", (req, res) => {
    res.json({ cta: generateCTA() });
});

module.exports = router;
// 🚀 NEW FEATURE END: FUNNEL ROUTES
