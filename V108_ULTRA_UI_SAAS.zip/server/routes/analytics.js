
// =====================
// 🚀 NEW FEATURE START: ANALYTICS ROUTES
// =====================
const express = require("express");
const router = express.Router();
const { track, getStats } = require("../analytics/engine");

router.post("/track",(req,res)=>{
    track(req.body.event);
    res.json({status:"tracked"});
});

router.get("/",(req,res)=>{
    res.json({stats:getStats()});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
