
        // 🚀 NEW FEATURE START: UNICORN ROUTES
        const express = require("express");
        const router = express.Router();

        const { personalize } = require("../unicorn/aiPersonalization");
        const { getActiveUsers } = require("../unicorn/userEngine");

        router.post("/ai", (req,res)=>{
            res.json({result: personalize(req.body.user)});
        });

        router.get("/users", (req,res)=>{
            res.json({users:getActiveUsers()});
        });

        module.exports = router;
        // 🚀 NEW FEATURE END
        