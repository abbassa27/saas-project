
// 🚀 NEW FEATURE START: AI ROUTES
const express = require("express");
const router = express.Router();
const { generateArticle } = require("../services/aiService");

router.post("/generate", async (req, res) => {
    const { topic } = req.body;
    const article = await generateArticle(topic);
    res.json({ article });
});

module.exports = router;
// 🚀 NEW FEATURE END: AI ROUTES
