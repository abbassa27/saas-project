
// 🚀 NEW FEATURE START: AUTOPILOT ROUTES
const express = require("express");
const router = express.Router();
const { runAutopilot } = require("../autopilot/loop");

router.get("/run", async (req, res) => {
    await runAutopilot();
    res.json({ status: "autopilot executed" });
});

module.exports = router;
// 🚀 NEW FEATURE END: AUTOPILOT ROUTES
