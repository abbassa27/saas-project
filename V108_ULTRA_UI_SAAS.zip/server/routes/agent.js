
// 🚀 NEW FEATURE START: AGENT ROUTES
const express = require("express");
const router = express.Router();
const { think, getDecisions } = require("../ai_agent/agentCore");

router.post("/think", (req, res) => {
    const { input } = req.body;
    const result = think(input);
    res.json({ result });
});

router.get("/logs", (req, res) => {
    res.json({ decisions: getDecisions() });
});

module.exports = router;
// 🚀 NEW FEATURE END: AGENT ROUTES
