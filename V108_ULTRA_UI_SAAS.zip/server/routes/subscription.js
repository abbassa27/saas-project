
// 🚀 NEW FEATURE START: SUBSCRIPTION ROUTES
const express = require("express");
const router = express.Router();
const Subscription = require("../models/Subscription");

router.post("/create", async (req, res) => {
    const { userId, plan } = req.body;
    const sub = new Subscription({ userId, plan });
    await sub.save();
    res.json(sub);
});

router.get("/:userId", async (req, res) => {
    const sub = await Subscription.findOne({ userId: req.params.userId });
    res.json(sub);
});

module.exports = router;
// 🚀 NEW FEATURE END: SUBSCRIPTION ROUTES
