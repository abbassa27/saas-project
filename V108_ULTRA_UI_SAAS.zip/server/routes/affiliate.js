
// =====================
// 🚀 NEW FEATURE START: AFFILIATE ROUTES
// =====================
const express = require("express");
const router = express.Router();
const { createLink, trackReferral, getReferrals } = require("../affiliate/system");

router.get("/link/:user",(req,res)=>{
    res.json({link:createLink(req.params.user)});
});

router.post("/track",(req,res)=>{
    trackReferral(req.body.user);
    res.json({status:"tracked"});
});

router.get("/",(req,res)=>{
    res.json({data:getReferrals()});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
