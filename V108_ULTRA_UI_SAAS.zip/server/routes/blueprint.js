
// 🚀 NEW FEATURE START: BLUEPRINT ROUTES
const express = require("express");
const path = require("path");
const router = express.Router();

router.get("/", (req, res) => {
    res.send("Blueprint available in /docs/blueprint");
});

router.get("/pdf", (req, res) => {
    const p = path.join(process.cwd(), "docs", "blueprint", "SYSTEM_BLUEPRINT.pdf");
    res.sendFile(p);
});

module.exports = router;
// 🚀 NEW FEATURE END: BLUEPRINT ROUTES
