
// =====================
// 🚀 NEW FEATURE START: AI UPGRADE ROUTES
// =====================
const express = require("express");
const router = express.Router();

const { generateTopContent } = require("../ai_upgrade/superWriter");

router.post("/generate", async (req,res)=>{
    const content = await generateTopContent(req.body.topic);
    res.json({content});
});

module.exports = router;
// =====================
// 🚀 NEW FEATURE END
// =====================
