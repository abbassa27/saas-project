
// 🚀 NEW FEATURE START: SEO ROUTES
const express = require("express");
const router = express.Router();
const { generateKeywords, seoScore } = require("../services/seoService");

router.post("/keywords", (req, res) => {
    const { topic } = req.body;
    res.json({ keywords: generateKeywords(topic) });
});

router.post("/score", (req, res) => {
    const { content } = req.body;
    res.json({ score: seoScore(content) });
});

module.exports = router;
// 🚀 NEW FEATURE END: SEO ROUTES
