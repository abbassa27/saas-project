
        // 🚀 NEW FEATURE START: PAYMENT ROUTES
        const express = require("express");
        const router = express.Router();
        const { createPayment, getPayments } = require("../payments/paymentSystem");

        router.post("/create", (req,res)=>{
            createPayment(req.body.user, req.body.amount);
            res.json({status:"payment_created"});
        });

        router.get("/", (req,res)=>{
            res.json({payments:getPayments()});
        });

        module.exports = router;
        // 🚀 NEW FEATURE END
        