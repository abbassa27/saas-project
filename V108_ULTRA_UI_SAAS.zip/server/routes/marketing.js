
        // 🚀 NEW FEATURE START: MARKETING ROUTES
        const express = require("express");
        const router = express.Router();
        const { launchCampaign, getCampaigns } = require("../marketing/engine");

        router.post("/launch", (req,res)=>{
            launchCampaign(req.body.name);
            res.json({status:"launched"});
        });

        router.get("/", (req,res)=>{
            res.json({campaigns:getCampaigns()});
        });

        module.exports = router;
        // 🚀 NEW FEATURE END
        