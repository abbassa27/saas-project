
// 🚀 NEW FEATURE START: TENANT MANAGER
const tenants = {};

const createTenant = (name) => {
    tenants[name] = { users: [] };
    return tenants[name];
};

const getTenant = (name) => tenants[name];

module.exports = { createTenant, getTenant };
// 🚀 NEW FEATURE END: TENANT MANAGER
