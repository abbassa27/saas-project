
// 🚀 NEW FEATURE START: AUTO ROUTE LOADER
const fs = require("fs");
const path = require("path");

const loadRoutes = (app) => {
    const routesPath = path.join(__dirname, "..", "routes");
    fs.readdirSync(routesPath).forEach(file => {
        if (file.endsWith(".js")) {
            const route = require(path.join(routesPath, file));
            const routeName = file.replace(".js", "");
            app.use(`/api/${routeName}`, route);
        }
    });
};

module.exports = loadRoutes;
// 🚀 NEW FEATURE END: AUTO ROUTE LOADER
