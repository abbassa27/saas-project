
// 🚀 NEW FEATURE START: SERVICE REGISTRY
const services = {};

const registerService = (name, service) => {
    services[name] = service;
};

const getService = (name) => services[name];

module.exports = { registerService, getService };
// 🚀 NEW FEATURE END: SERVICE REGISTRY
