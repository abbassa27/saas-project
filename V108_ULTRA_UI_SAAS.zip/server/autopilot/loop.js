
// 🚀 NEW FEATURE START: AUTOPILOT LOOP
const { scrapeJobs } = require("../real/upworkScraper");
const { generateProposal } = require("./aiProposal");
const { sendProposal } = require("../real/autoApply");

const runAutopilot = async () => {
    console.log("🤖 Autopilot running...");
    const jobs = await scrapeJobs("design");
    jobs.forEach(job => {
        const proposal = generateProposal(job);
        sendProposal({ ...job, proposal });
    });
};

module.exports = { runAutopilot };
// 🚀 NEW FEATURE END: AUTOPILOT LOOP
