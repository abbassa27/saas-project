
// 🚀 NEW FEATURE START: AI PROPOSAL GENERATOR
const generateProposal = (job) => {
    return `Hello ${job.client}, I will professionally handle your ${job.title} project.`;
};
module.exports = { generateProposal };
// 🚀 NEW FEATURE END: AI PROPOSAL GENERATOR
