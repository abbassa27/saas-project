
// 🚀 NEW FEATURE START: DB CONNECTION
const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Mongo connected");
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

module.exports = connectDB;
// 🚀 NEW FEATURE END: DB CONNECTION
