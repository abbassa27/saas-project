
// 🚀 NEW FEATURE START: PRODUCTION CONFIG
module.exports = {
    domain: process.env.DOMAIN || "http://localhost:3000",
    env: process.env.NODE_ENV || "development"
};
// 🚀 NEW FEATURE END: PRODUCTION CONFIG
