
// 🚀 NEW FEATURE START: FUNNEL SERVICE
const generateProposal = (clientName, project) => {
    return `Hello ${clientName}, I can help you with ${project} professionally.`;
};

const generateCTA = () => {
    return "Let's work together! Contact me now.";
};

module.exports = { generateProposal, generateCTA };
// 🚀 NEW FEATURE END: FUNNEL SERVICE
