
// 🚀 NEW FEATURE START: SEO SERVICE
const generateKeywords = (topic) => {
    return [topic, topic + " tips", topic + " guide"];
};

const seoScore = (content) => {
    return Math.min(100, content.length);
};

module.exports = { generateKeywords, seoScore };
// 🚀 NEW FEATURE END: SEO SERVICE
