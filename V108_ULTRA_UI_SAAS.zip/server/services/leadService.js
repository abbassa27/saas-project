
// 🚀 NEW FEATURE START: LEAD SERVICE
const getLeads = async (keyword) => {
    return [
        { name: "Client A", project: keyword + " project" },
        { name: "Client B", project: keyword + " website" }
    ];
};
module.exports = { getLeads };
// 🚀 NEW FEATURE END: LEAD SERVICE
