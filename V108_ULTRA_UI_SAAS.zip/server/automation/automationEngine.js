
// 🚀 NEW FEATURE START: AUTOMATION ENGINE
const cron = require("node-cron");

const startAutomation = () => {
    cron.schedule("0 * * * *", () => {
        console.log("Running hourly automation tasks...");
    });
};

module.exports = { startAutomation };
// 🚀 NEW FEATURE END: AUTOMATION ENGINE
