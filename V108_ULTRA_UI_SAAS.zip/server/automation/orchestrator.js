
// 🚀 NEW FEATURE START: FULL AUTO ORCHESTRATOR
const { runAutoBlog } = require("./autoBlog");
const { runAutoProposal } = require("./autoProposal");

const runAll = () => {
    console.log("Running FULL AUTO pipeline...");
    runAutoBlog();
    runAutoProposal();
};

module.exports = { runAll };
// 🚀 NEW FEATURE END: FULL AUTO ORCHESTRATOR
