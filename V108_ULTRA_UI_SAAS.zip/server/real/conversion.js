
// 🚀 NEW FEATURE START: CONVERSION TRACKING
let conversions = [];

const trackConversion = (event) => {
    conversions.push({ event, date: new Date() });
};

const getConversions = () => conversions;

module.exports = { trackConversion, getConversions };
// 🚀 NEW FEATURE END: CONVERSION TRACKING
