
// 🚀 NEW FEATURE START: AUTO APPLY
const sendProposal = (job) => {
    console.log("Sending proposal to:", job.client);
};
module.exports = { sendProposal };
// 🚀 NEW FEATURE END: AUTO APPLY
