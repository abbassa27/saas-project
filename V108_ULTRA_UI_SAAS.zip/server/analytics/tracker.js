
// 🚀 NEW FEATURE START: ANALYTICS TRACKER
const logs = [];

const track = (event) => {
    logs.push({ event, time: new Date() });
};

const getLogs = () => logs;

module.exports = { track, getLogs };
// 🚀 NEW FEATURE END: ANALYTICS TRACKER
