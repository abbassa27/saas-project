
// =====================
// 🚀 NEW FEATURE START: AFFILIATE SYSTEM
// =====================
let referrals = [];

const createLink = (user) => `/ref/${user}`;
const trackReferral = (user) => referrals.push({user, date:new Date()});
const getReferrals = () => referrals;

module.exports = { createLink, trackReferral, getReferrals };
// =====================
// 🚀 NEW FEATURE END
// =====================
