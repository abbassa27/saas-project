
// 🚀 NEW FEATURE START: USER MODEL
const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("User", UserSchema);
// 🚀 NEW FEATURE END: USER MODEL
