
// 🚀 NEW FEATURE START: SUBSCRIPTION MODEL
const mongoose = require("mongoose");

const SubscriptionSchema = new mongoose.Schema({
    userId: String,
    plan: { type: String, default: "free" },
    credits: { type: Number, default: 10 },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Subscription", SubscriptionSchema);
// 🚀 NEW FEATURE END: SUBSCRIPTION MODEL
