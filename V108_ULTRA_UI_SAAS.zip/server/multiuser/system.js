
// =====================
// 🚀 NEW FEATURE START: MULTI USER SYSTEM
// =====================
let users = [];

const register = (user) => {
    users.push({ ...user, limits: 10 });
};

const getUsers = () => users;

const useLimit = (index) => {
    if (users[index] && users[index].limits > 0) {
        users[index].limits -= 1;
    }
};

module.exports = { register, getUsers, useLimit };
// =====================
// 🚀 NEW FEATURE END
// =====================
