
// 🚀 NEW FEATURE START: AUTH MIDDLEWARE
const jwt = require("jsonwebtoken");

module.exports = function(req, res, next) {
    const token = req.header("Authorization");
    if (!token) return res.status(401).json({ msg: "No token" });

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (e) {
        res.status(401).json({ msg: "Invalid token" });
    }
};
// 🚀 NEW FEATURE END: AUTH MIDDLEWARE
