
// 🚀 NEW FEATURE START: PERFORMANCE OPTIMIZATION
module.exports = (req, res, next) => {
    res.setHeader("Cache-Control", "public, max-age=300");
    next();
};
// 🚀 NEW FEATURE END: PERFORMANCE OPTIMIZATION
