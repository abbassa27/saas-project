
// 🚀 NEW FEATURE START: ERROR HANDLER
module.exports = (err, req, res, next) => {
    console.error("Error:", err.message);
    res.status(500).json({ error: "Internal Server Error" });
};
// 🚀 NEW FEATURE END: ERROR HANDLER
