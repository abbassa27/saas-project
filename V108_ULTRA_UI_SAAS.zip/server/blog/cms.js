
// =====================
// 🚀 NEW FEATURE START: BLOG CMS
// =====================
let posts = [];

const createPost = (post) => posts.push(post);
const getPosts = () => posts;

module.exports = { createPost, getPosts };
// =====================
// 🚀 NEW FEATURE END
// =====================
