
// 🚀 NEW FEATURE START: REVENUE DASHBOARD
import React, { useEffect, useState } from "react";

export default function RevenueDashboard() {
    const [revenue, setRevenue] = useState(0);

    useEffect(() => {
        fetch("/api/revenue")
        .then(res => res.json())
        .then(data => setRevenue(data.revenue));
    }, []);

    return (
        <div style={{padding:20}}>
            <h2>Revenue Dashboard</h2>
            <h1>${revenue}</h1>
        </div>
    );
}
// 🚀 NEW FEATURE END: REVENUE DASHBOARD
