
// 🚀 NEW FEATURE START: ADMIN PAGE
import React, { useEffect, useState } from "react";

export default function Admin() {
    const [stats, setStats] = useState({});

    useEffect(() => {
        fetch("/api/admin/stats")
        .then(res => res.json())
        .then(data => setStats(data));
    }, []);

    return (
        <div style={{padding:20}}>
            <h2>Admin Dashboard</h2>
            <p>Users: {stats.users}</p>
            <p>Revenue: {stats.revenue}</p>
            <p>Tenants: {stats.activeTenants}</p>
        </div>
    );
}
// 🚀 NEW FEATURE END: ADMIN PAGE
