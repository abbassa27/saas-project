
// 🚀 NEW FEATURE START: SUBSCRIPTION PAGE
import React, { useState } from "react";

export default function Subscription() {
    const [userId, setUserId] = useState("");
    const [plan, setPlan] = useState("free");

    const create = async () => {
        await fetch("/api/subscription/create", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId, plan })
        });
        alert("Subscription created");
    };

    return (
        <div style={{padding:20}}>
            <h2>Subscription</h2>
            <input placeholder="User ID" onChange={e=>setUserId(e.target.value)} />
            <select onChange={e=>setPlan(e.target.value)}>
                <option value="free">Free</option>
                <option value="pro">Pro</option>
            </select>
            <button onClick={create}>Create</button>
        </div>
    );
}
// 🚀 NEW FEATURE END: SUBSCRIPTION PAGE
