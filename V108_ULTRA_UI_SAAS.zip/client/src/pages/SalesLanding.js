
// 🚀 NEW FEATURE START: SALES LANDING
import React from "react";

export default function SalesLanding() {
    return (
        <div style={{padding:40, textAlign:"center"}}>
            <h1>🚀 Get Clients Automatically</h1>
            <p>AI + SEO + Automation = Real Clients Daily</p>
            <button onClick={()=>alert("Start Now!")}>Start Now</button>
        </div>
    );
}
// 🚀 NEW FEATURE END: SALES LANDING
