
// 🚀 NEW FEATURE START: AI WRITER PAGE
import React, { useState } from "react";

export default function AIWriter() {
    const [topic, setTopic] = useState("");
    const [article, setArticle] = useState("");

    const generate = async () => {
        const res = await fetch("/api/ai/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ topic })
        });
        const data = await res.json();
        setArticle(data.article);
    };

    return (
        <div style={{padding:20}}>
            <h2>AI Blog Generator</h2>
            <input onChange={e=>setTopic(e.target.value)} placeholder="Topic" />
            <button onClick={generate}>Generate</button>
            <p>{article}</p>
        </div>
    );
}
// 🚀 NEW FEATURE END: AI WRITER PAGE
