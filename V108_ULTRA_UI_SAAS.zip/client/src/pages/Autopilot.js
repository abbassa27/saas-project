
// 🚀 NEW FEATURE START: AUTOPILOT UI
import React from "react";

export default function Autopilot() {
    const run = async () => {
        await fetch("/api/autopilot/run");
        alert("Autopilot executed");
    };

    return (
        <div style={{padding:20}}>
            <h2>Autopilot System</h2>
            <button onClick={run}>Run Now</button>
        </div>
    );
}
// 🚀 NEW FEATURE END: AUTOPILOT UI
