
// 🚀 NEW FEATURE START: LANDING PAGE
import React from "react";

export default function Landing() {
    return (
        <div style={{padding:40, textAlign:"center"}}>
            <h1>🚀 AI SaaS Growth System</h1>
            <p>Generate clients, content, and growth automatically.</p>
            <button onClick={()=>window.location.href="/dashboard"}>
                Get Started
            </button>
        </div>
    );
}
// 🚀 NEW FEATURE END: LANDING PAGE
