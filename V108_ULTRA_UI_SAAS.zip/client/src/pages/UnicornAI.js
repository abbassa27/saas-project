
        // 🚀 NEW FEATURE START: UNICORN AI UI
        import React, { useState } from "react";

        export default function UnicornAI(){
            const [user,setUser]=useState("");
            const [result,setResult]=useState("");

            const run = async ()=>{
                const res = await fetch("/api/unicorn/ai",{
                    method:"POST",
                    headers:{"Content-Type":"application/json"},
                    body:JSON.stringify({user})
                });
                const data = await res.json();
                setResult(data.result);
            };

            return(
                <div style={{padding:20}}>
                    <h2>AI Personalization</h2>
                    <input onChange={e=>setUser(e.target.value)} />
                    <button onClick={run}>Run</button>
                    <p>{result}</p>
                </div>
            )
        }
        // 🚀 NEW FEATURE END
        