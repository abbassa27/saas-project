
// 🚀 NEW FEATURE START: BLUEPRINT PAGE
import React from "react";

export default function Blueprint() {
    return (
        <div style={{padding:20}}>
            <h2>System Blueprint</h2>
            <p>Open the PDF or view docs in /docs/blueprint</p>
            <a href="/api/blueprint/pdf" target="_blank" rel="noreferrer">
                Open Blueprint PDF
            </a>
        </div>
    );
}
// 🚀 NEW FEATURE END: BLUEPRINT PAGE
