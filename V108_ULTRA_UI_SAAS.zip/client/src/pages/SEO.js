
// 🚀 NEW FEATURE START: SEO PAGE
import React, { useState } from "react";

export default function SEO() {
    const [topic, setTopic] = useState("");
    const [keywords, setKeywords] = useState([]);

    const getKeywords = async () => {
        const res = await fetch("/api/seo/keywords", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ topic })
        });
        const data = await res.json();
        setKeywords(data.keywords);
    };

    return (
        <div style={{padding:20}}>
            <h2>SEO Tool</h2>
            <input onChange={e=>setTopic(e.target.value)} placeholder="Topic" />
            <button onClick={getKeywords}>Generate Keywords</button>
            <ul>
                {keywords.map((k,i)=><li key={i}>{k}</li>)}
            </ul>
        </div>
    );
}
// 🚀 NEW FEATURE END: SEO PAGE
