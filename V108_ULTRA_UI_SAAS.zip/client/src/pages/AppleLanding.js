
// =====================
// 🚀 NEW FEATURE START: APPLE LANDING
// =====================
import React from "react";

export default function AppleLanding(){
    return(
        <div style={{
            background:"#000",
            color:"#fff",
            textAlign:"center",
            padding:"100px 20px",
            fontFamily:"-apple-system"
        }}>
            <h1 style={{fontSize:48,fontWeight:600}}>
                Build Your AI SaaS Empire 🚀
            </h1>
            <p style={{opacity:0.7}}>
                Automation + AI + Clients = Revenue Machine
            </p>
            <button style={{
                marginTop:30,
                padding:"15px 30px",
                borderRadius:30,
                border:"none",
                background:"#fff",
                color:"#000"
            }}>
                Get Started
            </button>
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
