
// 🚀 NEW FEATURE START: LEADS PAGE
import React, { useState } from "react";

export default function Leads() {
    const [keyword, setKeyword] = useState("");
    const [leads, setLeads] = useState([]);

    const fetchLeads = async () => {
        const res = await fetch("/api/leads", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ keyword })
        });
        const data = await res.json();
        setLeads(data.leads);
    };

    return (
        <div style={{padding:20}}>
            <h2>Lead Finder</h2>
            <input placeholder="Keyword" onChange={e=>setKeyword(e.target.value)} />
            <button onClick={fetchLeads}>Find Leads</button>
            <ul>
                {leads.map((l,i)=>(
                    <li key={i}>{l.name} - {l.project}</li>
                ))}
            </ul>
        </div>
    );
}
// 🚀 NEW FEATURE END: LEADS PAGE
