
// =====================
// 🚀 NEW FEATURE START: LOGIN UI
// =====================
import React, { useState } from "react";

export default function Login(){
    const [user,setUser]=useState("");

    const login = async ()=>{
        await fetch("/api/auth/login",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({user})
        });
        alert("Logged in");
    };

    return(
        <div style={{padding:20}}>
            <h2>Login</h2>
            <input onChange={e=>setUser(e.target.value)} />
            <button onClick={login}>Login</button>
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
