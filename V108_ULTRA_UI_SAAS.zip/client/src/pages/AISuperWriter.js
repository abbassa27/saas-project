
// =====================
// 🚀 NEW FEATURE START: AI SUPER WRITER UI
// =====================
import React, { useState } from "react";

export default function AISuperWriter(){
    const [topic,setTopic]=useState("");
    const [result,setResult]=useState("");

    const generate = async ()=>{
        const res = await fetch("/api/ai-upgrade/generate",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({topic})
        });
        const data = await res.json();
        setResult(data.content);
    };

    return(
        <div style={{padding:20}}>
            <h2>AI Super Writer</h2>
            <input onChange={e=>setTopic(e.target.value)} placeholder="Topic"/>
            <button onClick={generate}>Generate</button>
            <pre>{result}</pre>
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
