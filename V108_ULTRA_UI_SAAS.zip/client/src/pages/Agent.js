
// 🚀 NEW FEATURE START: AGENT PAGE
import React, { useState } from "react";

export default function Agent() {
    const [input, setInput] = useState("");
    const [output, setOutput] = useState("");

    const run = async () => {
        const res = await fetch("/api/agent/think", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ input })
        });
        const data = await res.json();
        setOutput(data.result);
    };

    return (
        <div style={{padding:20}}>
            <h2>AI Agent</h2>
            <input onChange={e=>setInput(e.target.value)} placeholder="Ask AI..." />
            <button onClick={run}>Run</button>
            <p>{output}</p>
        </div>
    );
}
// 🚀 NEW FEATURE END: AGENT PAGE
