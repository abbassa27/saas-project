
// 🚀 NEW FEATURE START: FUNNEL PAGE
import React, { useState } from "react";

export default function Funnel() {
    const [clientName, setClientName] = useState("");
    const [project, setProject] = useState("");
    const [proposal, setProposal] = useState("");

    const generate = async () => {
        const res = await fetch("/api/funnel/proposal", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ clientName, project })
        });
        const data = await res.json();
        setProposal(data.proposal);
    };

    return (
        <div style={{padding:20}}>
            <h2>Client Funnel</h2>
            <input placeholder="Client Name" onChange={e=>setClientName(e.target.value)} />
            <input placeholder="Project" onChange={e=>setProject(e.target.value)} />
            <button onClick={generate}>Generate Proposal</button>
            <p>{proposal}</p>
        </div>
    );
}
// 🚀 NEW FEATURE END: FUNNEL PAGE
