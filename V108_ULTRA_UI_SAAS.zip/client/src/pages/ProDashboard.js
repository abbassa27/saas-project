
        // 🚀 NEW FEATURE START: PRO DASHBOARD
        import React from "react";
        export default function ProDashboard(){
            return(
                <div style={{padding:20}}>
                    <h1>Pro Dashboard</h1>
                    <p>Users, Revenue, Campaigns overview</p>
                </div>
            )
        }
        // 🚀 NEW FEATURE END
        