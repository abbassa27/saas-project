
// 🚀 NEW FEATURE START: STATS CARD
import React from "react";

export default function StatsCard({ title, value }) {
    return (
        <div style={{
            padding:20,
            borderRadius:12,
            background:"#111",
            color:"#fff",
            marginBottom:10
        }}>
            <h4>{title}</h4>
            <h2>{value}</h2>
        </div>
    );
}
// 🚀 NEW FEATURE END: STATS CARD
