
// =====================
// 🚀 NEW FEATURE START: CUSTOM CURSOR
// =====================
import React, { useEffect } from "react";

export default function Cursor(){
    useEffect(()=>{
        const cursor = document.createElement("div");
        cursor.style.position="fixed";
        cursor.style.width="20px";
        cursor.style.height="20px";
        cursor.style.borderRadius="50%";
        cursor.style.background="gold";
        document.body.appendChild(cursor);

        document.addEventListener("mousemove",(e)=>{
            cursor.style.left=e.clientX+"px";
            cursor.style.top=e.clientY+"px";
        });
    },[]);
    return null;
}
// =====================
// 🚀 NEW FEATURE END
// =====================
