
// =====================
// 🚀 NEW FEATURE START: MICRO INTERACTIONS
// =====================
import React from "react";

export default function MicroButton({children}){
    return(
        <button style={{
            transition:"all 0.3s",
            padding:"10px 20px"
        }}
        onMouseOver={(e)=> e.target.style.transform="scale(1.1)"}
        onMouseOut={(e)=> e.target.style.transform="scale(1)"}
        >
            {children}
        </button>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
