
// =====================
// 🚀 NEW FEATURE START: 3D CARD EFFECT
// =====================
import React from "react";

export default function Card3D({children}){
    return(
        <div style={{
            transformStyle:"preserve-3d",
            transition:"transform 0.2s",
        }}
        onMouseMove={(e)=>{
            const x = e.nativeEvent.offsetX;
            const y = e.nativeEvent.offsetY;
            e.currentTarget.style.transform = `rotateX(${y/10}deg) rotateY(${x/10}deg)`
        }}
        onMouseLeave={(e)=>{
            e.currentTarget.style.transform = "rotateX(0deg) rotateY(0deg)"
        }}
        >
            {children}
        </div>
    )
}
// =====================
// 🚀 NEW FEATURE END
// =====================
