
// =====================
// 🚀 NEW FEATURE START: PARALLAX EFFECT
// =====================
import React, { useEffect } from "react";

export default function Parallax(){
    useEffect(()=>{
        const handle = ()=>{
            document.body.style.backgroundPositionY = window.scrollY * 0.5 + "px";
        };
        window.addEventListener("scroll", handle);
        return ()=> window.removeEventListener("scroll", handle);
    },[]);

    return null;
}
// =====================
// 🚀 NEW FEATURE END
// =====================
