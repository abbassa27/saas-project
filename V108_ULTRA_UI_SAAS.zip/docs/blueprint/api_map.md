
<!-- 🚀 NEW FEATURE START: API MAP -->
# API Map

## Auth
- POST /api/auth/register
- POST /api/auth/login

## AI
- POST /api/ai/generate

## SEO
- POST /api/seo/keywords
- POST /api/seo/score

## Funnel
- POST /api/funnel/proposal
- GET /api/funnel/cta

## Leads
- POST /api/leads

## Subscription
- POST /api/subscription/create
- GET /api/subscription/:userId

## Analytics
- GET /api/analytics

## Agent
- POST /api/agent/think
- GET /api/agent/logs

## Admin
- GET /api/admin/stats
<!-- 🚀 NEW FEATURE END: API MAP -->
