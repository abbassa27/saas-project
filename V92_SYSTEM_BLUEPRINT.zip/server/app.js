const express=require("express");
const mongoose=require("mongoose");
require("dotenv").config();

const app=express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI);

const Post=require("mongoose").model("Post",new mongoose.Schema({
 title:String,content:String,date:{type:Date,default:Date.now}
}));

setInterval(async ()=>{
 await Post.create({title:"Auto Post",content:"SEO content"});
},60000);

app.get("/api/blog",async(req,res)=>{
 res.json(await Post.find().sort({date:-1}));
});

app.get("/cta",(req,res)=>res.redirect(process.env.UPWORK_URL));

app.listen(5000);


// =====================
// 🚀 NEW FEATURE START: FULL SYSTEM INTEGRATION
// =====================
try {
    const loadRoutes = require("./loaders/routeLoader");
    const { startAutomation } = require("./automation/automationEngine");
    const { runAll } = require("./automation/orchestrator");

    // attach all routes automatically
    loadRoutes(app);

    // start automation safely
    if (startAutomation) startAutomation();

    // run orchestrator once at startup
    if (runAll) runAll();

    console.log("✅ Full system integration loaded");
} catch (e) {
    console.log("Integration layer skipped:", e.message);
}
// =====================
// 🚀 NEW FEATURE END: FULL SYSTEM INTEGRATION
// =====================


// =====================
// 🚀 NEW FEATURE START: PRODUCTION INIT
// =====================
try {
    const config = require("./production");
    console.log("🌍 Running in:", config.env);
    console.log("🔗 Domain:", config.domain);
} catch(e) {}
// =====================
// 🚀 NEW FEATURE END: PRODUCTION INIT
// =====================


// =====================
// 🚀 NEW FEATURE START: BLUEPRINT INTEGRATION
// =====================
try {
  const blueprintRoutes = require("./routes/blueprint");
  app.use("/api/blueprint", blueprintRoutes);
  console.log("📐 Blueprint routes mounted at /api/blueprint");
} catch(e) {}
// =====================
// 🚀 NEW FEATURE END: BLUEPRINT INTEGRATION
// =====================
