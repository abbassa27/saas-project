import React,{useEffect,useState} from "react";
import axios from "axios";
import {LineChart,Line,XAxis,YAxis,Tooltip} from "recharts";

export default function App(){
 const [posts,setPosts]=useState([]);

 useEffect(()=>{
  axios.get("http://localhost:5000/api/blog").then(r=>setPosts(r.data));
 },[]);

 return(
  <div>

    <div className="hero">
      <h1 className="glow parallax">Abbassa Malik</h1>
      <a href="http://localhost:5000/cta">
        <button className="btn">Start Your Project</button>
      </a>
    </div>

    <div style={{padding:"80px",textAlign:"center"}}>
      <h2>Dashboard</h2>
      <LineChart width={600} height={300} data={posts}>
        <XAxis dataKey="title"/>
        <YAxis/>
        <Tooltip/>
        <Line dataKey="date"/>
      </LineChart>
    </div>

    <div style={{padding:"80px"}}>
      <h2>Blog</h2>
      {posts.map(p=>(
        <div className="card" key={p._id}>
          <h3>{p.title}</h3>
          <p>{p.content}</p>
        </div>
      ))}
    </div>

  </div>
 )
}


// =====================
// 🚀 NEW FEATURE START: ROUTING SYSTEM
// =====================
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import ProtectedRoute from "./components/ProtectedRoute";

function AppRoutes() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/dashboard" element={
                    <ProtectedRoute>
                        <Dashboard />
                    </ProtectedRoute>
                } />
            </Routes>
        </Router>
    );
}

export { AppRoutes };
// =====================
// 🚀 NEW FEATURE END: ROUTING SYSTEM
// =====================


// =====================
// 🚀 NEW FEATURE START: GLOBAL ROUTE MOUNT
// =====================
import { AppRoutes } from "./App";

function IntegratedApp() {
  return <AppRoutes />;
}

export default IntegratedApp;
// =====================
// 🚀 NEW FEATURE END: GLOBAL ROUTE MOUNT
// =====================


// =====================
// 🚀 NEW FEATURE START: LAUNCH ROUTES
// =====================
import Landing from "./pages/Landing";
import SEOPage from "./pages/SEOPage";

export function LaunchRoutes() {
  return (
    <>
      <Landing />
      <SEOPage />
    </>
  );
}
// =====================
// 🚀 NEW FEATURE END: LAUNCH ROUTES
// =====================
